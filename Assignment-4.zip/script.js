function birthdayMatch() {
  var match=0;
	var k=0;
  var birthdayArray = [];
	for (;;) {
		var trials = parseInt(prompt("How many trials would you like"));
		if (!isNaN(trials)) break;
	}

	for (var a=0;a<trials;a++){
  for (var i=0;i<25;i++) {
    birthdayArray[i]=(Math.floor(Math.random()*365)+1);}
	birthdayArray.sort(function(a, b){return a - b});
	for(var k=1;k<25;k++) {
			if (birthdayArray[k-1]==birthdayArray[k]) {
				match++;
				break;
			}
		}
	}
	var output = match/trials;
	output = output*100;
	alert("There is a " + output.toFixed(2) + "% chance" + "\n that at least two out of 25 people have the same birthdays")
};

birthdayMatch();